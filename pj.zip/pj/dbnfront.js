//npm install -S mysql

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '0000',
  database : 'carrot' //db이름
});
 
connection.connect();
//                              ▽테이블이름
connection.query('SELECT * from csvjson', function (error, results, fields) {
  if (error) throw error;
  console.log('users: ', results);
});
 
connection.end();