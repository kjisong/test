
// const express = require('express');
// const mysql = require('mysql');

// const app = express();

// const connection = mysql.createConnection({
//   host     : 'localhost',
//   user     : 'root',
//   password : '0000',
//   database : 'carrot'
// });

// app.get('/', (req, res) => {
//   const query = 'SELECT * FROM csvjson';

//   connection.query(query, (err, rows) => {
//     if (err) {
//       throw err;
//     }

//     res.send(rows);
//   });
// });

// app.use(function(req, res) {
//   res.send(query);
// });

// app.listen(3000, () => {
//   console.log('Server is running on port 3000');
// });

// npm install express mysql2

const express = require('express');
const mysql = require('mysql2');

// 데이터베이스 연결 설정
const connection = mysql.createConnection({
  host     : 'localhost',
    user     : 'root',
    password : '0000',
    database : 'carrot'
});

// Express 앱 생성
const app = express();

// GET 요청에 대한 핸들러
app.get('/', (req, res) => {
  // 데이터베이스 쿼리 실행
  connection.query('SELECT * FROM csvjson', (error, results) => {
    if (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

// 서버 시작
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});

// 글자 깔끔하게 추출하는 것만 3시간째...ㅠㅠ

// const htmlText = '<div><p>This is <b>bold</b> text.</p><a href="https://example.com">Link</a></div>';

// const regex = /(<([^>]+)>)/gi;
// const plainText = htmlText.replace(regex, '');

// console.log(plainText);
