print('hello')
import requests
from bs4 import BeautifulSoup
wp = requests.get("https://www.daangn.com/hot_articles")
soup = BeautifulSoup(wp.content, "html.parser")
getItem = soup.select("#content > section.cards-wrap > article")
print(getItem)
for item in getItem:
    print(item.select('a > div.card-desc > h2')[0].text.strip(), end=",")
    print(item.select('a > div.card-desc > div.card-price')[0].text.strip(),end=",")
    print(item.select('a > div.card-desc > div.card-region-name')[0].text.strip(),end=",")
    print(item.select('a > div.card-desc > div.card-counts')[0].text.strip().replace(' ', '').replace('\n', '').replace('∙', ','))

file = open("apple.txt", "w") 
file.write('item')
file.close()    

import MySQLdb
