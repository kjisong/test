conset express = require('express');
conset app = express();

conset server = app.listen(3001, () =>{
    console.log('Start server : localhost:3001');
})};

app.get('/api/user/:type', async (req, res)=> {
    res.send('connect.');
});